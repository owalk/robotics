//////////////////////////////////////////////////////////////
//
// Programmer: Victoria Albanese
// Date: November 2, 2017
// Filename: map_class.hpp
//
// Description: This declares a class where 
//
//////////////////////////////////////////////////////////////

#ifndef MAP_CLASS_HPP
#define MAP_CLASS_HPP

#include <vector>

#include "ros/ros.h"
#include "nav_msgs/OccupancyGrid.h"
#include "nav_msgs/MapMetaData.h"
#include "std_msgs/Header.h"

#define L0 0.2
#define L_OCC 1.0
#define L_FREE 0.0

#define MAP_HEIGHT 150		// 150 pixels tall (15m)
#define MAP_WIDTH 600		// 600 pixels wide (60m)
#define MAP_RESOLUTION 0.1	// each pixel represents 0.1m = 10cm

using std::vector;

class MyMap 
{
private: 
  vector< vector<float> > map;

  /**
     this map will show if the robot has gone over that spot or not.
     after the code finishes, we can compare maps to see lawn mowed coverage.

     initialized to 0 at same size of other map. set to 1 when mower "mows" it.
   */
  vector< vector<int> > map_covered; // for if mowed with lawnmower
  ros::Publisher publisher;

public:
  MyMap();
  MyMap(ros::NodeHandle handle);
  vector< vector<float> > get_map() { return this->map; }
  void set_map(vector< vector<float> > new_map) { this->map = new_map; }

  /**
     looks in map for last column of unmowed stuff     
   */
  int find_unmowed();

  /**
     marks map_covered with a 1 where ever lawnmower robot has been.
   */
  void mark_as_mowed(int x, int y);
		
  void publish();
  float convert_to_probability(float log_odds);

  void draw_line(int x1, int y1, int x2, int y2);
  void draw_point(int x, int y, bool is_occupied);
  float update_log_odds(float old_odds, bool is_occupied);
};

#endif // MAP_CLASS_HPP

//////////////////////////////////////////////////////////////
